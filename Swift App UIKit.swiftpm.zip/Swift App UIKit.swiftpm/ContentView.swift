import SwiftUI

struct NavigationViewController: UIViewControllerRepresentable{
    func updateUIViewController(_ uiViewController: UIViewControllerType, context:Context){
        //do nothing
    }
    func makeUIViewController(context:Context)-> some UIViewController {
        let vc = ViewController()
        let navController = UINavigationController(rootViewController: vc)
        return navController
    }
}
